package at.fhv.ohe.uebung3.factory;

/**
 * An {@Link Exception} for an Illegal Trolly Attribute.
 *
 * Created by Oliver Heil on 29.03.2017.
 */
public class IllegalTrollyAttributes extends Exception{
        private static final long serialVersionUID = 1L;

}
