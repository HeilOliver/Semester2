package at.fhv.ohe.uebung3.enums;

/**
 * The Enums witch represent 4 Directions
 * 
 * @author Oliver H
 *
 */
public enum Direction {
	NORTH,
	SOUTH,
	WEST,
	EAST
}
